function startBattle(){
    window.location.href='../front-end/battle.html';
};

function restart(){
    window.location.href='../front-end/index.html';
    sessionStorage.clear();
};